﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your Age");
            int age=Convert.ToInt32(Console.ReadLine());
            if (age > 0)
            {
                if (age > 18 && age < 60)
                {
                    Console.Write("Adult...");
                }
                else if (age <= 18)
                {
                    Console.Write("TeenAger...");
                }
                else if (age >= 60)
                {
                    Console.Write("seniorcitision...");
                }
            }
            else
            {
                Console.Write("NO for leaving...");
            }
            Console.Read();

        }
    }
}
